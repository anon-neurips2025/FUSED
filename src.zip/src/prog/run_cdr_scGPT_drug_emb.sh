#!/bin/bash

#SBATCH --job-name=cdr-scgpt-drug          # A nice readable name of your job, to see it in the queue
#SBATCH --nodes=1                   # Number of nodes to request
#SBATCH --cpus-per-task=2           # Number of CPUs to request
#SBATCH --time=30:00:00
#SBATCH --gpus=1                    # Number of GPUs to request
#SBATCH --mail-type=END              # Receive an efficiency report at the end

module load conda

# Activate your environment, you have to create it first
conda activate deep-cdr-2

# Your job script goes below this line
python3 run_DeepCDR_drug_emb.py --ckpt_name scGPT_embeddings --run_id 1
python3 run_DeepCDR_drug_emb.py --ckpt_name scGPT_embeddings --run_id 2
python3 run_DeepCDR_drug_emb.py --ckpt_name scGPT_embeddings --run_id 3
python3 run_DeepCDR_drug_emb.py --ckpt_name scGPT_embeddings -use_mut -use_methy --run_id 1
python3 run_DeepCDR_drug_emb.py --ckpt_name scGPT_embeddings -use_mut -use_methy --run_id 2
python3 run_DeepCDR_drug_emb.py --ckpt_name scGPT_embeddings -use_mut -use_methy --run_id 3

python3 run_DeepCDR_drug_emb.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1
python3 run_DeepCDR_drug_emb.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 2
python3 run_DeepCDR_drug_emb.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 3
python3 run_DeepCDR_drug_emb.py --drug_emb molformer --ckpt_name scGPT_embeddings -use_mut -use_methy --run_id 1
python3 run_DeepCDR_drug_emb.py --drug_emb molformer --ckpt_name scGPT_embeddings -use_mut -use_methy --run_id 2
python3 run_DeepCDR_drug_emb.py --drug_emb molformer --ckpt_name scGPT_embeddings -use_mut -use_methy --run_id 3
