import argparse
import random,os
import numpy as np
import csv
import pandas as pd
import gc
#import keras.backend as K
from tensorflow.keras.callbacks import ModelCheckpoint,Callback
from tensorflow.keras.optimizers import Adam
import tensorflow.keras.backend as K
from tensorflow.keras.utils import Sequence
from scipy.stats import pearsonr,spearmanr
from model import KerasMultiSourceGCNModel, KerasMultiSourceDrugEmbModel
import hickle as hkl
import scipy.sparse as sp
import argparse
from tqdm import tqdm
#from keras import backend as K
import tensorflow as tf
import pickle

#print('GPU',K.tensorflow_backend._get_available_gpus())
print('GPU',tf.config.list_physical_devices('GPU'))

# gpus = tf.config.experimental.list_physical_devices('GPU')
# if gpus:
#     try:
#         for gpu in gpus:
#             tf.config.experimental.set_memory_growth(gpu, True)
#     except RuntimeError as e:
#         print(e)

####################################Settings#################################
parser = argparse.ArgumentParser(description='Drug_response_pre')
parser.add_argument('--run_id', dest='run_id', type=str, default='1', help='run id')
parser.add_argument('-gpu_id', dest='gpu_id', type=str, default='0', help='GPU devices')
parser.add_argument('-use_mut', dest='use_mut', action='store_true', default=False, help='use gene mutation or not')
parser.add_argument('-use_gexp', dest='use_gexp',  action='store_true', default=True, help='use gene expression or not')
parser.add_argument('-use_methy', dest='use_methy',  action='store_true', default=False, help='use methylation or not')

parser.add_argument('-israndom', dest='israndom', type=bool, default=False, help='randomlize X and A')
#hyparameters for GCN
#parser.add_argument('-unit_list', dest='unit_list', nargs='+', type=int, default=[256,256,256],help='unit list for GCN')
#parser.add_argument('-use_bn', dest='use_bn', type=bool, default=True, help='use batchnormalization for GCN')
#parser.add_argument('-use_relu', dest='use_relu', type=bool, default=True, help='use relu for GCN')
#parser.add_argument('-use_GMP', dest='use_GMP', type=bool, help='use GlobalMaxPooling for GCN')
parser.add_argument('-evaluate', dest='evaluate',  action='store_true', default=False, help='evaluate or not')
parser.add_argument('--ckpt_name', type=str, default=None, help='ckpt path')
parser.add_argument('--drug_emb', type=str, default="chemberta", help='drug emb path')
args = parser.parse_args()

os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id
use_mut,use_gexp,use_methy = args.use_mut,args.use_gexp, args.use_methy
israndom=args.israndom
model_suffix = ('with_mut' if use_mut else 'without_mut')+'_'+('with_gexp' if use_gexp else 'without_gexp')+'_'+('with_methy' if use_methy else 'without_methy')

# GCN_deploy = args.drug_emb + '_'+('bn' if args.use_bn else 'no_bn')+'_'+('relu' if args.use_relu else 'tanh')+'_'+('GMP' if args.use_GMP else 'GAP')
model_suffix = model_suffix + '_' + args.drug_emb

if args.ckpt_name is not None:
    model_suffix = model_suffix + '_' +args.ckpt_name


model_suffix = model_suffix + "_run_" + args.run_id 

print(model_suffix)
print(args)

####################################Constants Settings###########################
TCGA_label_set = ["ALL","BLCA","BRCA","CESC","DLBC","LIHC","LUAD",
                  "ESCA","GBM","HNSC","KIRC","LAML","LCML","LGG",
                  "LUSC","MESO","MM","NB","OV","PAAD","SCLC","SKCM",
                  "STAD","THCA",'COAD/READ']
DPATH = '../data'
Drug_info_file = '%s/GDSC/1.Drug_listMon Jun 24 09_00_55 2019.csv'%DPATH
Cell_line_info_file = '%s/CCLE/Cell_lines_annotations_20181226.txt'%DPATH
# Drug_feature_file = '%s/GDSC/drug_graph_feat'%DPATH
Drug_embedding_file = '%s/drug_embeddings/%s.pkl'% (DPATH,args.drug_emb)
Genomic_mutation_file = '%s/CCLE/genomic_mutation_34673_demap_features.csv'%DPATH
Cancer_response_exp_file = '%s/CCLE/GDSC_IC50.csv'%DPATH
Gene_expression_file = '%s/CCLE/genomic_expression_561celllines_697genes_demap_features.csv'%DPATH
Methylation_file = '%s/CCLE/genomic_methylation_561celllines_808genes_demap_features.csv'%DPATH
Max_atoms = 100

pcc_scores = []


def MetadataGenerate(Drug_info_file,Cell_line_info_file,Genomic_mutation_file,Gene_expression_file,Methylation_file,filtered):
    #drug_id --> pubchem_id
    reader = csv.reader(open(Drug_info_file,'r'))
    rows = [item for item in reader]
    drugid2pubchemid = {item[0]:item[5] for item in rows if item[5].isdigit()}

    #map cellline --> cancer type
    cellline2cancertype ={}
    for line in open(Cell_line_info_file).readlines()[1:]:
        cellline_id = line.split('\t')[1]
        TCGA_label = line.strip().split('\t')[-1]
        #if TCGA_label in TCGA_label_set:
        cellline2cancertype[cellline_id] = TCGA_label

    #load demap cell lines genomic mutation features
    mutation_feature = pd.read_csv(Genomic_mutation_file,sep=',',header=0,index_col=[0])
    cell_line_id_set = list(mutation_feature.index)

    # load drug features
    with open(Drug_embedding_file, 'rb') as f:
        drug_feature = pickle.load(f)
    drug_pubchem_id_set = set([key for key in drug_feature.keys()])
    
    #load gene expression faetures
    gexpr_feature = pd.read_csv(Gene_expression_file,sep=',',header=0,index_col=[0])
    
    #only keep overlapped cell lines
    mutation_feature = mutation_feature.loc[list(gexpr_feature.index)]
    
    #load methylation 
    methylation_feature = pd.read_csv(Methylation_file,sep=',',header=0,index_col=[0])
    assert methylation_feature.shape[0]==gexpr_feature.shape[0]==mutation_feature.shape[0]        
    experiment_data = pd.read_csv(Cancer_response_exp_file,sep=',',header=0,index_col=[0])
    #filter experiment data
    drug_match_list=[item for item in experiment_data.index if item.split(':')[1] in drugid2pubchemid.keys()]
    experiment_data_filtered = experiment_data.loc[drug_match_list]
    
    data_idx = []
    for each_drug in experiment_data_filtered.index:
        for each_cellline in experiment_data_filtered.columns:
            pubchem_id = drugid2pubchemid[each_drug.split(':')[-1]]
            if str(pubchem_id) in drug_pubchem_id_set and each_cellline in mutation_feature.index:
                if not np.isnan(experiment_data_filtered.loc[each_drug,each_cellline]) and each_cellline in cellline2cancertype.keys():
                    ln_IC50 = float(experiment_data_filtered.loc[each_drug,each_cellline])
                    data_idx.append((each_cellline,pubchem_id,ln_IC50,cellline2cancertype[each_cellline])) 
    nb_celllines = len(set([item[0] for item in data_idx]))
    nb_drugs = len(set([item[1] for item in data_idx]))
    print('%d instances across %d cell lines and %d drugs were generated.'%(len(data_idx),nb_celllines,nb_drugs))
    return mutation_feature, drug_feature, gexpr_feature,methylation_feature, data_idx

def DrugSplit(data_idx,drugtype = 'LUAD'):
    data_train_idx,data_test_idx = [], []
    data_test_idx = [item for item in data_idx if item[1]==drugtype]
    data_train_idx = [item for item in data_idx if item[1]!=drugtype]
    return data_train_idx,data_test_idx

#split into training and test set
def DataSplit(data_idx,ratio = 0.95):
    random.seed(args.run_id)
    data_train_idx,data_test_idx = [], []
    for each_type in TCGA_label_set:
        data_subtype_idx = [item for item in data_idx if item[-1]==each_type]
        train_list = random.sample(data_subtype_idx,int(ratio*len(data_subtype_idx)))
        test_list = [item for item in data_subtype_idx if item not in train_list]
        data_train_idx += train_list
        data_test_idx += test_list
    return data_train_idx,data_test_idx


def FeatureExtract(data_idx,drug_feature,mutation_feature,gexpr_feature,methylation_feature):
    cancer_type_list = []
    nb_instance = len(data_idx)
    nb_mutation_feature = mutation_feature.shape[1]
    nb_gexpr_features = gexpr_feature.shape[1]
    nb_methylation_features = methylation_feature.shape[1]
    drug_data = [[] for item in range(nb_instance)]
    mutation_data = np.zeros((nb_instance,1, nb_mutation_feature,1),dtype='float32')
    gexpr_data = np.zeros((nb_instance,nb_gexpr_features),dtype='float32') 
    methylation_data = np.zeros((nb_instance, nb_methylation_features),dtype='float32') 
    target = np.zeros(nb_instance,dtype='float32')
    for idx in tqdm(range(nb_instance)):
        cell_line_id,pubchem_id,ln_IC50,cancer_type = data_idx[idx]
        drug_data[idx] = drug_feature[str(pubchem_id)]
        #randomlize X A
        mutation_data[idx,0,:,0] = mutation_feature.loc[cell_line_id].values
        gexpr_data[idx,:] = gexpr_feature.loc[cell_line_id].values
        methylation_data[idx,:] = methylation_feature.loc[cell_line_id].values
        target[idx] = ln_IC50
        cancer_type_list.append([cancer_type,cell_line_id,pubchem_id])

    drug_data = np.array(drug_data)

    return drug_data,mutation_data,gexpr_data,methylation_data,target,cancer_type_list
    

class MyCallback(Callback):
    def __init__(self, validation_data, patience):
        self.validation_data = validation_data  # Should be a Sequence object (e.g., DrugResponseDataset)
        self.patience = patience
        self.best_weight = None

    def on_train_begin(self, logs=None):
        self.wait = 0
        self.stopped_epoch = 0
        self.best = -np.Inf
        self.val_ppc = []

    def on_train_end(self, logs=None):
        self.model.set_weights(self.best_weight)
        with open(f'{DPATH}/eval/pcc/DeepCDR_{model_suffix}.pickle', 'wb') as f:
            pickle.dump(self.val_ppc, f)
        if self.stopped_epoch > 0:
            print(f'Epoch {self.stopped_epoch + 1:05d}: early stopping')

        K.clear_session()
        

    def on_epoch_end(self, epoch, logs=None):
        # Predict batch-by-batch
        y_preds = []
        y_trues = []
        for x_batch, y_batch in self.validation_data:
            y_pred_batch = self.model.predict(x_batch, verbose=0)
            y_preds.append(y_pred_batch[:, 0])
            y_trues.append(y_batch)

        y_pred_val = np.concatenate(y_preds)
        y_val = np.concatenate(y_trues)

        pcc_val = pearsonr(y_val, y_pred_val)[0]
        self.val_ppc.append(pcc_val)
        print(f'pcc-val: {round(pcc_val, 4)}')

        if pcc_val > self.best:
            self.best = pcc_val
            self.wait = 0
            self.best_weight = self.model.get_weights()
        else:
            self.wait += 1
            if self.wait >= self.patience:
                self.stopped_epoch = epoch
                self.model.stop_training = True

        # Clean up
        del y_pred_val, y_val, y_preds, y_trues, pcc_val
        gc.collect()
        

class DrugResponseDataset(Sequence):
    def __init__(self, drug_data, mutation_data, gexpr_data, methylation_data, targets, batch_size=64, shuffle=True):
        self.drug_data = drug_data
        self.mutation_data = mutation_data                                # (N, 1, num_mut_features, 1)
        self.gexpr_data = gexpr_data                                      # (N, num_gexpr_features)
        self.methylation_data = methylation_data                          # (N, num_methy_features)
        self.targets = targets                                            # (N,)
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.indices = np.arange(len(self.targets))
        self.on_epoch_end()

    def __len__(self):
        return int(np.ceil(len(self.targets) / self.batch_size))

    def __getitem__(self, index):
        start = index * self.batch_size
        end = (index + 1) * self.batch_size
        idxs = self.indices[start:end]

        # Select the data slices
        X = [
            self.drug_data[idxs],             # fm Drug features embs
            self.mutation_data[idxs],        # Mutation data
            self.gexpr_data[idxs],           # Gene expression data
            self.methylation_data[idxs]      # Methylation data
        ]
        y = self.targets[idxs]

        return X, y
    
    def on_epoch_end(self):
        if self.shuffle:
            np.random.shuffle(self.indices)

def ModelTraining(model, train_dataset, val_dataset, nb_epoch=100):
    optimizer = Adam(learning_rate=0.001)
    model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['mse'])

    callbacks = [MyCallback(validation_data=val_dataset, patience=10)]

    model.fit(train_dataset, epochs=nb_epoch, callbacks=callbacks)
    return model

def ModelEvaluate(model, test_dataset):
    y_preds = []
    y_trues = []
    for x_batch, y_batch in test_dataset:
        y_pred_batch = model.predict(x_batch, verbose=0)
        y_preds.append(y_pred_batch[:, 0])
        y_trues.append(y_batch)

    y_pred_test = np.concatenate(y_preds)
    y_test = np.concatenate(y_trues)

    pcc_test = pearsonr(y_test, y_pred_test)[0]
    print(f'pcc-test: {round(pcc_test, 4)}')
    return y_pred_test, y_test
    

def main():
    save_path = f'{DPATH}/eval/leave_drug_opt/{model_suffix}'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
        
    mutation_feature, drug_feature,gexpr_feature,methylation_feature, data_idx = MetadataGenerate(Drug_info_file,Cell_line_info_file,Genomic_mutation_file,Gene_expression_file,Methylation_file,False)
    print('raw fea',gexpr_feature.shape)
    
    if args.ckpt_name is not None:
        gexpr_np = np.load('../data/{}.npy'.format(args.ckpt_name))
        gexpr_feature = pd.DataFrame(gexpr_np,index=gexpr_feature.index)
        print('load embeddings from {}.npy!!!!!!!'.format(args.ckpt_name))
        print(gexpr_feature.shape)

    drugnames = list(set([item[1] for item in data_idx]))
    for drugname in drugnames:
        # check if drug was already processed
        if os.path.exists(f"{save_path}/{drugname}.npz"):
            continue
        
        data_train_idx,data_test_idx = DrugSplit(data_idx,drugname)
        data_train_idx, data_val_idx = DataSplit(data_train_idx)

        #Extract features for training and test 
        X_drug_data_train,X_mutation_data_train,X_gexpr_data_train,X_methylation_data_train,Y_train,cancer_type_train_list = FeatureExtract(data_train_idx,drug_feature,mutation_feature,gexpr_feature,methylation_feature)
        X_drug_data_test,X_mutation_data_test,X_gexpr_data_test,X_methylation_data_test,Y_test,cancer_type_test_list = FeatureExtract(data_test_idx,drug_feature,mutation_feature,gexpr_feature,methylation_feature)
        X_drug_data_val,X_mutation_data_val,X_gexpr_data_val,X_methylation_data_val,Y_val,cancer_type_val_list = FeatureExtract(data_val_idx,drug_feature,mutation_feature,gexpr_feature,methylation_feature)
        
        # Create dataset generators
        train_dataset = DrugResponseDataset(X_drug_data_train, X_mutation_data_train, X_gexpr_data_train, X_methylation_data_train, Y_train, batch_size=64)
        val_dataset = DrugResponseDataset(X_drug_data_val, X_mutation_data_val, X_gexpr_data_val, X_methylation_data_val, Y_val, batch_size=64, shuffle=False)
        test_dataset = DrugResponseDataset(X_drug_data_test, X_mutation_data_test, X_gexpr_data_test, X_methylation_data_test, Y_test, batch_size=64, shuffle=False)
        model = KerasMultiSourceDrugEmbModel(use_mut,use_gexp,use_methy).createMaster(X_drug_data_train[0].shape[-1],X_mutation_data_train.shape[-2],X_gexpr_data_train.shape[-1],X_methylation_data_train.shape[-1])

        model = ModelTraining(model, train_dataset, val_dataset, nb_epoch=100)
        Y_pred, Y_test = ModelEvaluate(model, test_dataset)

        np.savez(f"{save_path}/{drugname}.npz",
                 cancer_type=np.array(cancer_type_test_list)[:,0],
                 cellline=np.array(cancer_type_test_list)[:,1],
                 pubchem_id = np.array(cancer_type_test_list)[:,2], 
                 pred = Y_pred,test = Y_test)
        
        # clean up
        del model
        del data_train_idx,data_test_idx
        del X_drug_data_train,X_mutation_data_train,X_gexpr_data_train,X_methylation_data_train,Y_train, cancer_type_train_list
        del X_drug_data_test,X_mutation_data_test,X_gexpr_data_test,X_methylation_data_test, cancer_type_test_list
        del X_drug_data_val,X_mutation_data_val,X_gexpr_data_val,X_methylation_data_val,Y_val, cancer_type_val_list
        del train_dataset, val_dataset, test_dataset
        del Y_pred,Y_test
        gc.collect()

if __name__=='__main__':
    main()
    
