import tensorflow as tf
from tensorflow.keras import layers, Model, regularizers, initializers, constraints, activations
from tensorflow.keras.layers import Layer, Dense, Dropout, BatchNormalization, GlobalMaxPooling1D, GlobalAveragePooling1D, Conv2D, MaxPooling2D, Flatten, Activation, Input, Concatenate, Lambda, Reshape
import tensorflow.keras.backend as K

class GraphLayer(Layer):
    def __init__(self, step_num=1, activation=None, **kwargs):
        super(GraphLayer, self).__init__(**kwargs)
        self.step_num = step_num
        self.activation = activations.get(activation)
        self.supports_masking = True

    def get_config(self):
        config = super().get_config()
        config.update({
            'step_num': self.step_num,
            'activation': activations.serialize(self.activation)
        })
        return config

    def _get_walked_edges(self, edges, step_num):
        if step_num <= 1:
            return edges
        deeper = self._get_walked_edges(tf.matmul(edges, edges), step_num // 2)
        if step_num % 2 == 1:
            deeper += edges
        return tf.cast(K.greater(deeper, 0.0), K.floatx())

    def call(self, inputs, **kwargs):
        features, edges = inputs
        edges = tf.cast(edges, tf.keras.backend.floatx())
        if self.step_num > 1:
            edges = self._get_walked_edges(edges, self.step_num)
        return self.activation(self._call(features, edges))

    def _call(self, features, edges):
        raise NotImplementedError('This method should be implemented in subclass.')


class GraphConv(GraphLayer):
    def __init__(self, units,
                 kernel_initializer='glorot_uniform',
                 kernel_regularizer=None,
                 kernel_constraint=None,
                 use_bias=True,
                 bias_initializer='zeros',
                 bias_regularizer=None,
                 bias_constraint=None,
                 **kwargs):
        super(GraphConv, self).__init__(**kwargs)
        self.units = units
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.kernel_regularizer = regularizers.get(kernel_regularizer)
        self.kernel_constraint = constraints.get(kernel_constraint)
        self.use_bias = use_bias
        self.bias_initializer = initializers.get(bias_initializer)
        self.bias_regularizer = regularizers.get(bias_regularizer)
        self.bias_constraint = constraints.get(bias_constraint)

    def build(self, input_shape):
        feature_dim = input_shape[0][-1]
        self.W = self.add_weight(shape=(feature_dim, self.units),
                                 initializer=self.kernel_initializer,
                                 regularizer=self.kernel_regularizer,
                                 constraint=self.kernel_constraint,
                                 name='W')
        if self.use_bias:
            self.b = self.add_weight(shape=(self.units,),
                                     initializer=self.bias_initializer,
                                     regularizer=self.bias_regularizer,
                                     constraint=self.bias_constraint,
                                     name='b')
        super(GraphConv, self).build(input_shape)

    def get_config(self):
        config = super().get_config()
        config.update({
            'units': self.units,
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'kernel_regularizer': regularizers.serialize(self.kernel_regularizer),
            'kernel_constraint': constraints.serialize(self.kernel_constraint),
            'use_bias': self.use_bias,
            'bias_initializer': initializers.serialize(self.bias_initializer),
            'bias_regularizer': regularizers.serialize(self.bias_regularizer),
            'bias_constraint': constraints.serialize(self.bias_constraint),
        })
        return config

    def _call(self, features, edges):
        h = tf.matmul(features, self.W)
        if self.use_bias:
            h += self.b
        return tf.matmul(tf.transpose(edges, perm=[0, 2, 1]), h)


class GraphPool(GraphLayer):
    def compute_mask(self, inputs, mask=None):
        return mask[0]


class GraphMaxPool(GraphPool):
    NEG_INF = -1e38

    def _call(self, features, edges):
        node_num = K.shape(features)[1]
        expanded = tf.expand_dims(features, axis=1)
        tiled = tf.tile(expanded, [1, node_num, 1, 1])
        masked = tiled + tf.expand_dims((1.0 - edges) * self.NEG_INF, axis=-1)
        return K.max(masked, axis=2)


class GraphAveragePool(GraphPool):
    def _call(self, features, edges):
        return tf.matmul(tf.transpose(edges, perm=[0, 2, 1]), features) / (K.sum(edges, axis=2, keepdims=True) + K.epsilon())


class KerasMultiSourceGCNModel:
    def __init__(self, use_mut=False, use_gexp=True, use_methy=False, regr=True):
        self.use_mut = use_mut
        self.use_gexp = use_gexp
        self.use_methy = use_methy
        self.regr = regr
        print('Model config:', self.use_mut, self.use_gexp, self.use_methy)

    def createMaster(self, drug_dim, mut_dim, gexpr_dim, methy_dim, units_list, use_relu=True, use_bn=True, use_GMP=True):
        drug_feat_input = Input(shape=(None, drug_dim), name='drug_feat_input')
        drug_adj_input = Input(shape=(None, None), name='drug_adj_input')
        gexpr_input = Input(shape=(gexpr_dim), name='gexpr_feat_input')
        mut_input = Input(shape=(1, mut_dim, 1), name='mut_feat_input')
        methy_input = Input(shape=(methy_dim,), name='methy_feat_input')

        # Drug GCN processing
        x = GraphConv(units=units_list[0], step_num=1)([drug_feat_input, drug_adj_input])
        x = Activation('relu' if use_relu else 'tanh')(x)
        if use_bn:
            x = BatchNormalization()(x)
        x = Dropout(0.1)(x)

        for units in units_list[1:]:
            x = GraphConv(units=units, step_num=1)([x, drug_adj_input])
            x = Activation('relu' if use_relu else 'tanh')(x)
            if use_bn:
                x = BatchNormalization()(x)
            x = Dropout(0.1)(x)

        x = GraphConv(units=100, step_num=1)([x, drug_adj_input])
        x = Activation('relu' if use_relu else 'tanh')(x)
        if use_bn:
            x = BatchNormalization()(x)
        x = Dropout(0.1)(x)

        x_drug = GlobalMaxPooling1D()(x) if use_GMP else GlobalAveragePooling1D()(x)

        # Gene Expression
        x_inputs = [x_drug]
        input_layers = [drug_feat_input, drug_adj_input, mut_input, gexpr_input, methy_input]
        
        if self.use_gexp:
            x_gexpr = Dense(256)(gexpr_input)
            x_gexpr = Activation('tanh')(x_gexpr)
            x_gexpr = BatchNormalization()(x_gexpr)
            x_gexpr = Dropout(0.1)(x_gexpr)
            x_gexpr = Dense(100, activation='relu')(x_gexpr)
            x_inputs.append(x_gexpr)

        if self.use_mut:
            x_mut = Conv2D(filters=50, kernel_size=(1, 700), strides=(1, 5), activation='tanh', padding='valid')(mut_input)
            x_mut = MaxPooling2D(pool_size=(1, 5))(x_mut)
            x_mut = Conv2D(filters=30, kernel_size=(1, 5), strides=(1, 2), activation='relu', padding='valid')(x_mut)
            x_mut = MaxPooling2D(pool_size=(1, 10))(x_mut)
            x_mut = Flatten()(x_mut)
            x_mut = Dense(100, activation='relu')(x_mut)
            x_mut = Dropout(0.1)(x_mut)
            x_inputs.append(x_mut)

        if self.use_methy:
            x_methy = Dense(256)(methy_input)
            x_methy = Activation('tanh')(x_methy)
            x_methy = BatchNormalization()(x_methy)
            x_methy = Dropout(0.1)(x_methy)
            x_methy = Dense(100, activation='relu')(x_methy)
            x_inputs.append(x_methy)

        x = Concatenate()(x_inputs)

        x = Dense(300, activation='tanh')(x)
        x = Dropout(0.1)(x)
        x = Lambda(lambda t: tf.expand_dims(tf.expand_dims(t, 1), -1))(x)  # (batch, 1, 300, 1)

        x = Conv2D(30, (1, 150), activation='relu', padding='valid')(x)
        x = MaxPooling2D((1, 2))(x)
        x = Conv2D(10, (1, 5), activation='relu', padding='valid')(x)
        x = MaxPooling2D((1, 3))(x)
        x = Conv2D(5, (1, 5), activation='relu', padding='valid')(x)
        x = MaxPooling2D((1, 3))(x)

        x = Dropout(0.1)(x)
        x = Flatten()(x)
        x = Dropout(0.2)(x)

        output = Dense(1, name='output')(x) if self.regr else Dense(1, activation='sigmoid', name='output')(x)

        model = Model(inputs=input_layers, outputs=output)
        return model
    

class KerasMultiSourceDrugEmbModel:
    def __init__(self, use_mut=False, use_gexp=True, use_methy=False, regr=True):
        self.use_mut = use_mut
        self.use_gexp = use_gexp
        self.use_methy = use_methy
        self.regr = regr
        print('Model config:', self.use_mut, self.use_gexp, self.use_methy)

    def createMaster(self, drug_dim, mut_dim, gexpr_dim, methy_dim):
        drug_input = Input(shape=(drug_dim), name='drug_emb_input')
        gexpr_input = Input(shape=(gexpr_dim), name='gexpr_feat_input')
        mut_input = Input(shape=(1, mut_dim, 1), name='mut_feat_input')
        methy_input = Input(shape=(methy_dim,), name='methy_feat_input')
        
        input_layers = [drug_input, mut_input, gexpr_input, methy_input]
        x_inputs = []
        x_inputs.append(drug_input)
        
        if self.use_gexp:
            x_gexpr = Dense(256)(gexpr_input)
            x_gexpr = Activation('tanh')(x_gexpr)
            x_gexpr = BatchNormalization()(x_gexpr)
            x_gexpr = Dropout(0.1)(x_gexpr)
            x_gexpr = Dense(100, activation='relu')(x_gexpr)
            x_inputs.append(x_gexpr)

        if self.use_mut:
            x_mut = Conv2D(filters=50, kernel_size=(1, 700), strides=(1, 5), activation='tanh', padding='valid')(mut_input)
            x_mut = MaxPooling2D(pool_size=(1, 5))(x_mut)
            x_mut = Conv2D(filters=30, kernel_size=(1, 5), strides=(1, 2), activation='relu', padding='valid')(x_mut)
            x_mut = MaxPooling2D(pool_size=(1, 10))(x_mut)
            x_mut = Flatten()(x_mut)
            x_mut = Dense(100, activation='relu')(x_mut)
            x_mut = Dropout(0.1)(x_mut)
            x_inputs.append(x_mut)

        if self.use_methy:
            x_methy = Dense(256)(methy_input)
            x_methy = Activation('tanh')(x_methy)
            x_methy = BatchNormalization()(x_methy)
            x_methy = Dropout(0.1)(x_methy)
            x_methy = Dense(100, activation='relu')(x_methy)
            x_inputs.append(x_methy)

        x = Concatenate()(x_inputs)

        x = Dense(300, activation='tanh')(x)
        x = Dropout(0.1)(x)
        x = Lambda(lambda t: tf.expand_dims(tf.expand_dims(t, 1), -1))(x)  # (batch, 1, 300, 1)

        x = Conv2D(30, (1, 150), activation='relu', padding='valid')(x)
        x = MaxPooling2D((1, 2))(x)
        x = Conv2D(10, (1, 5), activation='relu', padding='valid')(x)
        x = MaxPooling2D((1, 3))(x)
        x = Conv2D(5, (1, 5), activation='relu', padding='valid')(x)
        x = MaxPooling2D((1, 3))(x)

        x = Dropout(0.1)(x)
        x = Flatten()(x)
        x = Dropout(0.2)(x)

        output = Dense(1, name='output')(x) if self.regr else Dense(1, activation='sigmoid', name='output')(x)

        model = Model(inputs=input_layers, outputs=output)
        return model

