import torch
import torch.nn as nn
import torch.nn.functional as F

class TB_Fusion(nn.Module):
    def __init__(self, embed_dim=50, num_embs=4, num_heads=4, dropout=0.1):
        super(TB_Fusion, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.max_seq_len = num_embs

        # One attention layer per token position
        self.attn_layers = nn.ModuleList([
            nn.MultiheadAttention(embed_dim, num_heads, dropout=dropout, batch_first=True)
            for _ in range(num_embs)
        ])

        self.norms1 = nn.ModuleList([nn.LayerNorm(embed_dim) for _ in range(num_embs)])

        self.fnn = nn.Sequential(
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim, embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )


    def forward(self, src):
        # src shape: (batch_size, seq_len, embed_dim)
        batch_size, seq_len, embed_dim = src.size()
        assert seq_len <= self.max_seq_len, f"Input sequence length {seq_len} exceeds max_seq_len {self.max_seq_len}"

        attended = []
        for i in range(seq_len):
            x = src[:, i:i+1, :]  # shape: (batch, 1, embed_dim)
            attn_layer = self.attn_layers[i]  # Use the specific attention layer for this position
            out, _ = attn_layer(x, src, src)  # (batch, 1, embed_dim)
            out = out + x
            out = self.norms1[i](out)
            attended.append(out)

        attn_output = torch.cat(attended, dim=1)  # shape: (batch, seq_len, embed_dim)

        src = self.fnn(attn_output)  # Apply feedforward network
        return src

class TB(nn.Module):
    def __init__(self, embed_dim=50, num_embs=4, num_heads=4, dim_feedforward=50, dropout=0.1):
        super(TB, self).__init__()
        self.self_attn = nn.MultiheadAttention(embed_dim, num_heads, dropout=dropout)
        self.linear1 = nn.Linear(embed_dim, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, embed_dim)

        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, src):
        src2, _ = self.self_attn(src, src, src, attn_mask=None, key_padding_mask=None)
        src = src + self.dropout1(src2)
        src = self.norm1(src)
        src2 = self.linear2(self.dropout(F.relu(self.linear1(src))))
        src = src + self.dropout2(src2)
        src = self.norm2(src)
        return src
    
class EmbModel(nn.Module):
    def __init__(self, input_dim, embed_dim, hidden_dim=500):
        super(EmbModel, self).__init__()
        self.input_dim = input_dim
        self.embed_dim = embed_dim
        self.nn = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Tanh(),
            nn.BatchNorm1d(hidden_dim),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, embed_dim),
            nn.ReLU()
        )
    
    def forward(self, x):
        return self.nn(x)

class MutationModel(nn.Module):
    def __init__(self, input_shape, embed_dim):
        super(MutationModel, self).__init__()
        assert input_shape== 34673, "Input shape for mutation model must be 34673, or change linear layer input size."
        self.nn = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=50, kernel_size=700, stride=5, padding=0),
            nn.Tanh(),
            nn.MaxPool1d(kernel_size=5),
            nn.Conv1d(in_channels=50, out_channels=30, kernel_size=5, stride=2, padding=0),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=10),
            nn.Flatten(),
            nn.Linear(2010, embed_dim),
            nn.ReLU(),
            nn.Dropout(0.1)
        )


    def forward(self, x):
        return self.nn(x.unsqueeze(1))


    
class CDR_Attn_Model(nn.Module):
    def __init__(self, gexp_dim, mut_dim, meth_dim, drug_dim, hyperparam, multi_omics=True):
        super(CDR_Attn_Model, self).__init__()
        self.embed_dim = hyperparam['embed_dim']
        self.hidden_layer = hyperparam['hidden_layer']
        self.num_heads = hyperparam['num_heads']
        self.multi_omics = multi_omics
        self.num_embs = 4 if multi_omics else 2

        self.gexp_model = EmbModel(gexp_dim, self.embed_dim)
        if self.multi_omics:
            self.mut_model = MutationModel(mut_dim, self.embed_dim)
            self.meth_model = EmbModel(meth_dim, self.embed_dim)
        self.drug_model = EmbModel(drug_dim, self.embed_dim)

        self.attn = hyperparam["attn"]
        if self.attn == "fusion":
            print("apply fusion TB")
            self.attn_model = TB_Fusion(embed_dim=self.embed_dim, num_embs=self.num_embs, num_heads=self.num_heads)
        elif self.attn == "single":
            print("apply single TB")
            self.attn_model = TB(embed_dim=self.embed_dim, num_embs=self.num_embs, num_heads=self.num_heads)

        self.fnn_input_dim = self.num_embs * self.embed_dim
        
        # Define the feedforward neural network (FNN) layers
        layers = []
        for i in range(len(self.hidden_layer)):
            layers.append(nn.Linear(self.fnn_input_dim if i == 0 else self.hidden_layer[i-1], self.hidden_layer[i]))
            layers.append(nn.BatchNorm1d(self.hidden_layer[i]))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))

        layers.append(nn.Linear(self.hidden_layer[-1], 1))  # Output layer
        self.fnn = nn.Sequential(*layers)

    def forward(self, gexp, mut, meth, drug):
        gexp_emb = self.gexp_model(gexp)
        if self.multi_omics:
            mut_emb = self.mut_model(mut)
            meth_emb = self.meth_model(meth)
        drug_emb = self.drug_model(drug)

        ffn_input = [gexp_emb, mut_emb, meth_emb, drug_emb] if self.multi_omics else [gexp_emb, drug_emb]

        if self.attn:
            embs = torch.stack(ffn_input, dim=1)
            output = self.attn_model(embs)
            output = output.view(output.size(0), -1)
            # print("<<test>>")
            # print(output.shape)
        else:
            output = torch.cat(ffn_input, dim=1)
            print("<<test>>")
            print(output.shape)            

        return self.fnn(output).squeeze()
        


        