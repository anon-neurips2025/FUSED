import argparse
import random, os
import numpy as np
import pandas as pd
import gc
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
import hickle as hkl
import scipy.sparse as sp
from tqdm import tqdm
import pickle
from scipy.stats import pearsonr,spearmanr
from transformers import get_scheduler

from hybridDataset import HybridDataset
from attn_model import CDR_Attn_Model
from utils import generate_grid_search_params, MetadataGenerate, DataSplit, DrugSplit, FeatureExtract

####################################Settings#################################
parser = argparse.ArgumentParser(description='Drug_response_pre')
parser.add_argument('--run_id', dest='run_id', type=str, default='0', help='run id')
parser.add_argument('-gpu_id', dest='gpu_id', type=str, default='0', help='GPU devices')
parser.add_argument('--ckpt_name', type=str, default=None, help='ckpt path')
parser.add_argument('--drug_emb', type=str, default="chemberta", help='drug emb path')
parser.add_argument('--attn', type=str, default=None, help='specify wether to use attn or not for fusion of embs')
parser.add_argument('--multi_omics', action='store_true', default=False, help="wheter to use mutation and methylation data")
args = parser.parse_args()

random.seed(int(args.run_id))
np.random.seed(int(args.run_id))
torch.manual_seed(int(args.run_id))

os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
if args.attn:
    model_suffix = 'fusion' + '_' + args.attn + '_' + args.drug_emb
else:
    model_suffix = 'fusion_mlp' + '_' + args.drug_emb
if args.ckpt_name is not None:
    model_suffix += '_' + args.ckpt_name
model_suffix = model_suffix + "_multi-omics" if args.multi_omics else model_suffix + "_transcriptomics"
model_suffix += "_run_" + args.run_id

print(model_suffix)
print(args)

####################################Constants Settings###########################
TCGA_label_set = ["ALL","BLCA","BRCA","CESC","DLBC","LIHC","LUAD",
                  "ESCA","GBM","HNSC","KIRC","LAML","LCML","LGG",
                  "LUSC","MESO","MM","NB","OV","PAAD","SCLC","SKCM",
                  "STAD","THCA",'COAD/READ']

DPATH = f'../data'
Drug_info_file = f'{DPATH}/GDSC/1.Drug_listMon Jun 24 09_00_55 2019.csv'
Cell_line_info_file = f'{DPATH}/CCLE/Cell_lines_annotations_20181226.txt'
Drug_embedding_file = f'{DPATH}/drug_embeddings/{args.drug_emb}.pkl'
Genomic_mutation_file = f'{DPATH}/CCLE/genomic_mutation_34673_demap_features.csv'
Cancer_response_exp_file = f'{DPATH}/CCLE/GDSC_IC50.csv'
Gene_expression_file = f'{DPATH}/CCLE/genomic_expression_561celllines_697genes_demap_features.csv'
Methylation_file = f'{DPATH}/CCLE/genomic_methylation_561celllines_808genes_demap_features.csv'




def train(model, train_loader, val_loader, optimizer, criterion, scheduler, num_epochs=60):
    model.to(device)
    best_loss = float('inf')
    best_model_state = None
    pcc_history = []

    for epoch in range(num_epochs):
        model.train()
        train_loss = 0.0
        for batch in train_loader:
            inputs = [b.to(device) for b in batch[:-1]]
            targets = batch[-1].to(device)
            #print(targets.shape)

            optimizer.zero_grad()
            outputs = model(*inputs)
            #print(outputs.shape)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            scheduler.step()
            train_loss += loss.item()

        # Validation
        model.eval()
        val_loss = 0.0
        ic50_preds, ic50_true = [], []
        with torch.no_grad():
            for batch in val_loader:
                inputs = [b.to(device) for b in batch[:-1]]
                targets = batch[-1].to(device)
                outputs = model(*inputs)

                ic50_preds.extend(outputs.cpu().numpy())
                ic50_true.extend(targets.cpu().numpy())

                loss = criterion(outputs, targets)
                val_loss += loss.item()
        
        pcc_score = pearsonr(ic50_true, ic50_preds)[0]
        pcc_history.append(pcc_score)

        print(f"Epoch {epoch + 1}/{num_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, PCC score: {pcc_score:.4f}")

        if val_loss < best_loss:
            best_loss = val_loss
            best_model_state = model.state_dict()
    
    model.load_state_dict(best_model_state)

    return model, pcc_history

def test(model, test_loader):
    model.eval()
    model.to(device)
    ic50_preds, ic50_true = [], []

    with torch.no_grad():
        for batch in test_loader:
            inputs = [b.to(device) for b in batch[:-1]]
            targets = batch[-1].to(device)
            outputs = model(*inputs)

            ic50_preds.extend(outputs.cpu().numpy())
            ic50_true.extend(targets.cpu().numpy())

    pcc_score = pearsonr(ic50_true, ic50_preds)[0]
    print(f"PCC Score: {pcc_score:.4f}")

    return pcc_score


def main():
    save_path = f'{DPATH}/eval/grid_search'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    # Load all features
    mutation_feature, drug_feature, gexpr_feature, methylation_feature, data_idx = MetadataGenerate(
        Drug_info_file,Cell_line_info_file,Genomic_mutation_file,Gene_expression_file,Methylation_file,Drug_embedding_file, Cancer_response_exp_file)

    if args.ckpt_name is not None:
        gexpr_np = np.load(f'{DPATH}/{args.ckpt_name}.npy')
        gexpr_feature = pd.DataFrame(gexpr_np, index=gexpr_feature.index)

    # Split data
    data_train_idx, data_test_idx= DataSplit(data_idx, TCGA_label_set, args.run_id, ratio=0.05)
    data_train_idx, data_val_idx= DataSplit(data_train_idx, TCGA_label_set, args.run_id)

    # Extract features for each split
    X_drug_data_train, X_mutation_data_train, X_gexpr_data_train, X_methylation_data_train, Y_train, _ = FeatureExtract(
        data_train_idx, drug_feature, mutation_feature, gexpr_feature, methylation_feature)
    X_drug_data_val, X_mutation_data_val, X_gexpr_data_val, X_methylation_data_val, Y_val, _ = FeatureExtract(
        data_val_idx, drug_feature, mutation_feature, gexpr_feature, methylation_feature)
    X_drug_data_test, X_mutation_data_test, X_gexpr_data_test, X_methylation_data_test, Y_test, _ = FeatureExtract(
        data_test_idx, drug_feature, mutation_feature, gexpr_feature, methylation_feature)

    # Create datasets
    data_train = HybridDataset(X_drug_data_train, X_mutation_data_train, X_gexpr_data_train, X_methylation_data_train, Y_train)
    data_val = HybridDataset(X_drug_data_val, X_mutation_data_val, X_gexpr_data_val, X_methylation_data_val, Y_val)
    data_test = HybridDataset(X_drug_data_test, X_mutation_data_test, X_gexpr_data_test, X_methylation_data_test, Y_test)

    # Data loaders
    batch_size = 64
    train_loader = DataLoader(data_train, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(data_val, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(data_test, batch_size=batch_size, shuffle=False)

    # Grid search
    results = []
    hyperparameters = generate_grid_search_params(args.attn)
    num_epochs = 1
    num_train_steps = int((len(data_train) // batch_size) * num_epochs)

    for idx, hyperparameter in enumerate(hyperparameters):
        hyperparameter['attn'] = args.attn
        print(f"\nRunning grid search {idx + 1}/{len(hyperparameters)}: {hyperparameter}")
        # print(X_drug_data_train.shape[-1],X_mutation_data_train.shape[-1],X_gexpr_data_train.shape[-1],X_methylation_data_train.shape[-1])
        model = CDR_Attn_Model(X_drug_data_train.shape[-1],X_mutation_data_train.shape[-1],X_gexpr_data_train.shape[-1],X_methylation_data_train.shape[-1], hyperparameter)
        optimizer = torch.optim.AdamW(model.parameters(), lr=hyperparameter['lr'])
        scheduler = get_scheduler(
            "cosine",
            optimizer=optimizer,
            num_warmup_steps=int(0.05 * num_train_steps),
            num_training_steps=num_train_steps
        )
        criterion = nn.MSELoss()

        model, pcc_val = train(model, train_loader, val_loader, optimizer, criterion, scheduler, num_epochs)

        results.append({
            'pcc_val': np.max(pcc_val),
            'history': pcc_val,
            'embed_dim': hyperparameter['embed_dim'],
            'hidden_layer': hyperparameter['hidden_layer'],
            'lr': hyperparameter['lr'],
            'attn': hyperparameter['attn'],
            'num_heads': hyperparameter['num_heads']
        })

        # delete to free memory
        model.cpu()
        del model, optimizer, criterion
        torch.cuda.empty_cache()
        gc.collect()

    results_df = pd.DataFrame(results)
    results_df.to_csv(os.path.join(save_path, f'{model_suffix}.csv'), index=False)

if __name__ == '__main__':
    main()
