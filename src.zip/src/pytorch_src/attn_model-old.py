import torch
import torch.nn as nn
import torch.nn.functional as F

class ScaledDotProductAttention(nn.Module):
    def __init__(self, d_k):
        super(ScaledDotProductAttention, self).__init__()
        self.scale = d_k ** 0.5

    def forward(self, Q, K, V, mask=None):
        # Q, K, V: (batch_size, seq_len, d_k)
        scores = torch.matmul(Q, K.transpose(-2, -1)) / self.scale  # (batch_size, seq_len, seq_len)

        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))

        attn_weights = F.softmax(scores, dim=-1)  # (batch_size, seq_len, seq_len)
        output = torch.matmul(attn_weights, V)  # (batch_size, seq_len, d_k)
        return output, attn_weights

class SelfAttention(nn.Module):
    def __init__(self, embed_dim):
        super(SelfAttention, self).__init__()
        self.d_k = embed_dim
        self.query = nn.Linear(embed_dim, embed_dim)
        self.key = nn.Linear(embed_dim, embed_dim)
        self.value = nn.Linear(embed_dim, embed_dim)
        self.attn = ScaledDotProductAttention(embed_dim)
        self.out = nn.Linear(embed_dim, embed_dim)

    def forward(self, x, mask=None):
        Q = self.query(x)
        K = self.key(x)
        V = self.value(x)
        attn_output, attn_weights = self.attn(Q, K, V, mask)
        output = self.out(attn_output)  # Final linear layer
        return output, attn_weights

class TransformerBlock(nn.Module):
    def __init__(self, embed_dim):
        super(TransformerBlock, self).__init__()
        self.attention = SelfAttention(embed_dim)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.ff = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.ReLU(),
            nn.Linear(embed_dim * 4, embed_dim)
        )
        self.norm2 = nn.LayerNorm(embed_dim)

    def forward(self, x):
        attn_out, attn_weights = self.attention(x)
        x = self.norm1(x + attn_out)  # Residual + norm
        ff_out = self.ff(x)
        x = self.norm2(x + ff_out)
        return x, attn_weights
    
class EmbModel(nn.Module):
    def __init__(self, input_dim, embed_dim=256):
        super(EmbModel, self).__init__()
        self.input_dim = input_dim
        self.embed_dim = embed_dim
        self.nn = nn.Sequential(
            nn.Linear(input_dim, embed_dim),
            nn.Tanh(),
            nn.BatchNorm1d(embed_dim),
            nn.Dropout(0.1),
            nn.Linear(embed_dim, 100),
            nn.ReLU()
        )
    
    def forward(self, x):
        return self.nn(x)

class MutationModel(nn.Module):
    def __init__(self, input_shape):
        super(MutationModel, self).__init__()
        assert input_shape== 34673, "Input shape for mutation model must be 34673, or change linear layer input size."
        self.nn = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=50, kernel_size=700, stride=5, padding=0),
            nn.Tanh(),
            nn.MaxPool1d(kernel_size=5),
            nn.Conv1d(in_channels=50, out_channels=30, kernel_size=5, stride=2, padding=0),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=10),
            nn.Flatten(),
            nn.Linear(2010, 100),
            nn.ReLU(),
            nn.Dropout(0.1)
        )


    def forward(self, x):
        return self.nn(x.unsqueeze(1))


    
class CDR_Attn_Model(nn.Module):
    def __init__(self, gexp_dim, mut_dim, meth_dim, drug_dim, hyperparam, multi_omics=True):
        super(CDR_Attn_Model, self).__init__()
        self.embed_dim = 100
        self.hidden_layer = hyperparam['hidden_layer']
        self.multi_omics = multi_omics
        self.num_embs = 4 if multi_omics else 2

        self.gexp_model = EmbModel(gexp_dim)
        if self.multi_omics:
            self.mut_model = MutationModel(mut_dim)
            self.meth_model = EmbModel(meth_dim)
        self.drug_model = EmbModel(drug_dim)

        self.attn = hyperparam["attn"]
        if self.attn:
            self.attn_model = TransformerBlock(embed_dim=self.embed_dim)

        self.fnn_input_dim = self.embed_dim if self.attn else self.num_embs * self.embed_dim
        
        # Define the feedforward neural network (FNN) layers
        layers = []
        for i in range(len(self.hidden_layer)):
            layers.append(nn.Linear(self.fnn_input_dim if i == 0 else self.hidden_layer[i-1], self.hidden_layer[i]))
            layers.append(nn.BatchNorm1d(self.hidden_layer[i]))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))

        layers.append(nn.Linear(self.hidden_layer[-1], 1))  # Output layer
        self.fnn = nn.Sequential(*layers)

    def forward(self, gexp, mut, meth, drug):
        gexp_emb = self.gexp_model(gexp)
        if self.multi_omics:
            mut_emb = self.mut_model(mut)
            meth_emb = self.meth_model(meth)
        drug_emb = self.drug_model(drug)

        ffn_input = [gexp_emb, mut_emb, meth_emb, drug_emb] if self.multi_omics else [gexp_emb, drug_emb]

        if self.attn:
            embs = torch.stack(ffn_input, dim=1)
            attn_output, attn_weights = self.attn_model(embs)
            pooled_output = torch.mean(attn_output, dim=1)
        else:
            pooled_output = torch.cat(ffn_input, dim=1)

        return self.fnn(pooled_output).squeeze()
        


        