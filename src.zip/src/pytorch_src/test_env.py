import argparse
import random, os
import numpy as np
import pandas as pd
import gc
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
import hickle as hkl
import scipy.sparse as sp
from tqdm import tqdm
import pickle
from scipy.stats import pearsonr,spearmanr

from hybridDataset import HybridDataset
from attn_model import CDR_Attn_Model
from utils import generate_grid_search_params, MetadataGenerate, DataSplit, FeatureExtract

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)