import numpy as np
from tqdm import tqdm
import random
import pandas as pd
import pickle
import csv

def generate_grid_search_params(attn):
    lrs = [0.0001, 0.00001]
    layers = [[100, 50], [100]]
    num_heads = [2, 5, 10] if attn else ["not used"]
    embed_dims = [50, 100, 200]
    hyperparameters = []

    for lr in lrs:
        for layer in layers:
            for num_head in num_heads:
                for embed_dim in embed_dims:
                    hyperparameters.append({
                        'hidden_layer': layer,
                        'lr': lr,
                        'num_heads': num_head,
                        'embed_dim': embed_dim
                    })
    return hyperparameters

def MetadataGenerate(Drug_info_file,Cell_line_info_file,Genomic_mutation_file,Gene_expression_file,Methylation_file,Drug_embedding_file, Cancer_response_exp_file):
    #drug_id --> pubchem_id
    reader = csv.reader(open(Drug_info_file,'r'))
    rows = [item for item in reader]
    drugid2pubchemid = {item[0]:item[5] for item in rows if item[5].isdigit()}

    #map cellline --> cancer type
    cellline2cancertype ={}
    for line in open(Cell_line_info_file).readlines()[1:]:
        cellline_id = line.split('\t')[1]
        TCGA_label = line.strip().split('\t')[-1]
        #if TCGA_label in TCGA_label_set:
        cellline2cancertype[cellline_id] = TCGA_label

    #load demap cell lines genomic mutation features
    mutation_feature = pd.read_csv(Genomic_mutation_file,sep=',',header=0,index_col=[0])
    cell_line_id_set = list(mutation_feature.index)

    # load drug features
    with open(Drug_embedding_file, 'rb') as f:
        drug_feature = pickle.load(f)
    drug_pubchem_id_set = set([key for key in drug_feature.keys()])
    
    #load gene expression faetures
    gexpr_feature = pd.read_csv(Gene_expression_file,sep=',',header=0,index_col=[0])
    
    #only keep overlapped cell lines
    mutation_feature = mutation_feature.loc[list(gexpr_feature.index)]
    
    #load methylation 
    methylation_feature = pd.read_csv(Methylation_file,sep=',',header=0,index_col=[0])
    assert methylation_feature.shape[0]==gexpr_feature.shape[0]==mutation_feature.shape[0]        
    experiment_data = pd.read_csv(Cancer_response_exp_file,sep=',',header=0,index_col=[0])
    #filter experiment data
    drug_match_list=[item for item in experiment_data.index if item.split(':')[1] in drugid2pubchemid.keys()]
    experiment_data_filtered = experiment_data.loc[drug_match_list]
    
    data_idx = []
    for each_drug in experiment_data_filtered.index:
        for each_cellline in experiment_data_filtered.columns:
            pubchem_id = drugid2pubchemid[each_drug.split(':')[-1]]
            if str(pubchem_id) in drug_pubchem_id_set and each_cellline in mutation_feature.index:
                if not np.isnan(experiment_data_filtered.loc[each_drug,each_cellline]) and each_cellline in cellline2cancertype.keys():
                    ln_IC50 = float(experiment_data_filtered.loc[each_drug,each_cellline])
                    data_idx.append((each_cellline,pubchem_id,ln_IC50,cellline2cancertype[each_cellline])) 
    nb_celllines = len(set([item[0] for item in data_idx]))
    nb_drugs = len(set([item[1] for item in data_idx]))

    return mutation_feature, drug_feature, gexpr_feature,methylation_feature, data_idx

def FeatureExtract(data_idx,drug_feature,mutation_feature,gexpr_feature,methylation_feature):
    cancer_type_list = []
    nb_instance = len(data_idx)
    nb_mutation_feature = mutation_feature.shape[1]
    nb_gexpr_features = gexpr_feature.shape[1]
    nb_methylation_features = methylation_feature.shape[1]
    drug_data = [[] for item in range(nb_instance)]
    # mutation_data = np.zeros((nb_instance,1, nb_mutation_feature,1),dtype='float32')
    mutation_data = np.zeros((nb_instance, nb_mutation_feature),dtype='float32')
    gexpr_data = np.zeros((nb_instance,nb_gexpr_features),dtype='float32') 
    methylation_data = np.zeros((nb_instance, nb_methylation_features),dtype='float32') 
    target = np.zeros(nb_instance,dtype='float32')
    for idx in tqdm(range(nb_instance)):
        cell_line_id,pubchem_id,ln_IC50,cancer_type = data_idx[idx]
        drug_data[idx] = drug_feature[str(pubchem_id)]
        #randomlize X A
        mutation_data[idx,:] = mutation_feature.loc[cell_line_id].values
        gexpr_data[idx,:] = gexpr_feature.loc[cell_line_id].values
        methylation_data[idx,:] = methylation_feature.loc[cell_line_id].values
        target[idx] = ln_IC50
        cancer_type_list.append([cancer_type,cell_line_id,pubchem_id])

    drug_data = np.array(drug_data,  dtype=np.float32)

    return drug_data,mutation_data,gexpr_data,methylation_data,target,cancer_type_list

#split into training and test set
def DataSplit(data_idx, TCGA_label_set, run_id=1, ratio = 0.95):
    random.seed(run_id)
    data_train_idx,data_test_idx = [], []
    for each_type in TCGA_label_set:
        data_subtype_idx = [item for item in data_idx if item[-1]==each_type]
        train_list = random.sample(data_subtype_idx,int(ratio*len(data_subtype_idx)))
        test_list = [item for item in data_subtype_idx if item not in train_list]
        data_train_idx += train_list
        data_test_idx += test_list
    return data_train_idx,data_test_idx

def DrugSplit(data_idx,drugtype = 'LUAD'):
    data_train_idx,data_test_idx, data_val_idx = [], [], []
    data_test_idx = [item for item in data_idx if item[1]==drugtype]
    data_train_idx = [item for item in data_idx if item[1]!=drugtype]

    return data_train_idx, data_test_idx