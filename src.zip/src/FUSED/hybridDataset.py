from torch.utils.data import Dataset
import torch

class HybridDataset(Dataset):
    def __init__(self, drug_data, mutation_data, gexpr_data, methylation_data, ic50):
        self.drug_data = drug_data
        self.mutation_data = mutation_data
        self.gexpr_data = gexpr_data
        self.methylation_data = methylation_data
        self.ic50 = ic50

    def __len__(self):
        return len(self.ic50)

    def __getitem__(self, idx):
        return self.gexpr_data[idx], self.mutation_data[idx], self.methylation_data[idx], self.drug_data[idx], self.ic50[idx]
        # return self.drug_data[idx], self.mutation_data[idx], self.gexpr_data[idx], self.methylation_data[idx], self.ic50[idx]
                            