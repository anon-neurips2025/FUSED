#!/bin/bash

#SBATCH --job-name=fused-gs           # A nice readable name of your job, to see it in the queue
#SBATCH --nodes=1                   # Number of nodes to request
#SBATCH --cpus-per-task=1          # Number of CPUs to request
#SBATCH --gpus=1                    # Number of GPUs to request
#SBATCH --mail-type=END              # Receive an efficiency report at the end

module load conda

# Activate your environment, you have to create it first
conda activate pytorch-cdr

python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1 --multi_omics
python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 1 --multi_omics
python3 run_attn_cdr_gs.py --drug_emb molformer --run_id 1 --multi_omics

python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1 --attn fusion --multi_omics
python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scFoundation_embeddings --run_id 1 --attn fusion --multi_omics

python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1 --attn single --multi_omics
python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scFoundation_embeddings --run_id 1 --attn single --multi_omics

python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1
python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 1

python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1 --attn fusion
python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scFoundation_embeddings --run_id 1 --attn fusion

python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scGPT_embeddings --run_id 1 --attn single
python3 run_attn_cdr_gs.py --drug_emb molformer --ckpt_name scFoundation_embeddings --run_id 1 --attn single
