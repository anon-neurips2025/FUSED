#!/bin/bash

#SBATCH --job-name=default          # A nice readable name of your job, to see it in the queue
#SBATCH --nodes=1                   # Number of nodes to request
#SBATCH --cpus-per-task=1           # Number of CPUs to request
#SBATCH --gpus=1                    # Number of GPUs to request
#SBATCH --mail-type=END              # Receive an efficiency report at the end

module load conda

# Activate your environment, you have to create it first
conda activate pytorch-cdr

python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn fusion --run_id 1
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn fusion --run_id 2
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn fusion --run_id 3

python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn single --run_id 1
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn single --run_id 2
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn single --run_id 3

python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 1
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 2
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 3

python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn fusion --run_id 1 --multi_omics
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn fusion --run_id 2 --multi_omics
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn fusion --run_id 3 --multi_omics

python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn single --run_id 1 --multi_omics
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn single --run_id 2 --multi_omics
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --attn single --run_id 3 --multi_omics

python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 1 --multi_omics
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 2 --multi_omics
python3 run_attn_cdr.py --drug_emb molformer --ckpt_name scFound_embeddings --run_id 3 --multi_omics

