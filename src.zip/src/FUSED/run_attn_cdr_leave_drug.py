import argparse
import random, os
import numpy as np
import pandas as pd
import gc
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
import hickle as hkl
import scipy.sparse as sp
from tqdm import tqdm
import pickle
from scipy.stats import pearsonr,spearmanr
from transformers import get_scheduler

from hybridDataset import HybridDataset
from attn_model import CDR_Attn_Model
from utils import generate_grid_search_params, MetadataGenerate, DataSplit, DrugSplit, FeatureExtract

#200,[100],0.0001,fusion,10
####################################Settings#################################
parser = argparse.ArgumentParser(description='Drug_response_pre')
parser.add_argument('--run_id', dest='run_id', type=str, default='0', help='run id')
parser.add_argument('-gpu_id', dest='gpu_id', type=str, default='0', help='GPU devices')
parser.add_argument('--ckpt_name', type=str, default="scGPT_embeddings", help='ckpt path')
parser.add_argument('--drug_emb', type=str, default="chemberta", help='drug emb path')
parser.add_argument('--attn', type=str, default=None, help='specify wether to use attn or not for fusion of embs')
parser.add_argument('--embed_dim', type=int, default=200, help='specify embed dim for attn module')
parser.add_argument('--lr', type=float, default=0.0001, help='specify lr')
parser.add_argument('--hidden_layer', type=list, default=[100], help='specify hidden layer dims in MLP after concat embs')
parser.add_argument('--num_heads', type=int, default=10, help='specify num heads in attn module')
parser.add_argument('--multi_omics', action='store_true', default=False, help="wheter to use mutation and methylation data")
parser.add_argument('--start', type=int, default=0, help='start idx for drug list')
args = parser.parse_args()

assert args.embed_dim % args.num_heads == 0, "embed_dim must be divisible by num_heads"

random.seed(int(args.run_id))
np.random.seed(int(args.run_id))
torch.manual_seed(int(args.run_id))

os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

if args.attn:
    model_suffix = 'fusion' + '_' + args.attn + '_' + args.drug_emb
else:
    model_suffix = 'fusion_mlp' + '_' + args.drug_emb
if args.ckpt_name is not None:
    model_suffix += '_' + args.ckpt_name
model_suffix = "NEW" + model_suffix + "_multi-omics" if args.multi_omics else model_suffix + "_transcriptomics"
model_suffix += "_run_" + args.run_id

print(model_suffix)
print(args)

####################################Constants Settings###########################
TCGA_label_set = ["ALL","BLCA","BRCA","CESC","DLBC","LIHC","LUAD",
                  "ESCA","GBM","HNSC","KIRC","LAML","LCML","LGG",
                  "LUSC","MESO","MM","NB","OV","PAAD","SCLC","SKCM",
                  "STAD","THCA",'COAD/READ']

DPATH = f'../data'
Drug_info_file = f'{DPATH}/GDSC/1.Drug_listMon Jun 24 09_00_55 2019.csv'
Cell_line_info_file = f'{DPATH}/CCLE/Cell_lines_annotations_20181226.txt'
Drug_embedding_file = f'{DPATH}/drug_embeddings/{args.drug_emb}.pkl'
Genomic_mutation_file = f'{DPATH}/CCLE/genomic_mutation_34673_demap_features.csv'
Cancer_response_exp_file = f'{DPATH}/CCLE/GDSC_IC50.csv'
Gene_expression_file = f'{DPATH}/CCLE/genomic_expression_561celllines_697genes_demap_features.csv'
Methylation_file = f'{DPATH}/CCLE/genomic_methylation_561celllines_808genes_demap_features.csv'




def train(model, train_loader, val_loader, optimizer, criterion, scheduler, num_epochs=60):
    model.to(device)
    best_loss = float('inf')
    best_model_state = None
    pcc_history = []
    counter = 0

    for epoch in range(num_epochs):
        model.train()
        train_loss = 0.0
        for batch in train_loader:
            inputs = [b.to(device) for b in batch[:-1]]
            targets = batch[-1].to(device)
            if targets.shape[0] == 1:
                continue

            optimizer.zero_grad()
            outputs = model(*inputs)
            #print(outputs.shape)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            scheduler.step()
            train_loss += loss.item()

        # Validation
        model.eval()
        val_loss = 0.0
        ic50_preds, ic50_true = [], []
        with torch.no_grad():
            for batch in val_loader:
                inputs = [b.to(device) for b in batch[:-1]]
                targets = batch[-1].to(device)
                outputs = model(*inputs)

                ic50_preds.extend(outputs.cpu().numpy())
                ic50_true.extend(targets.cpu().numpy())

                loss = criterion(outputs, targets)
                val_loss += loss.item()
        
        pcc_score = pearsonr(ic50_true, ic50_preds)[0]
        pcc_history.append(pcc_score)

        print(f"Epoch {epoch + 1}/{num_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, PCC score: {pcc_score:.4f}")

        if val_loss < best_loss:
            best_loss = val_loss
            best_model_state = model.state_dict()
            counter = 0 
        else:
            counter += 1
            if counter >= 10:
                break

    
    model.load_state_dict(best_model_state)

    return model, pcc_history

def test(model, test_loader):
    model.eval()
    model.to(device)
    ic50_preds, ic50_true = [], []

    with torch.no_grad():
        for batch in test_loader:
            inputs = [b.to(device) for b in batch[:-1]]
            targets = batch[-1].to(device)
            outputs = model(*inputs)

            ic50_preds.extend(outputs.cpu().numpy())
            ic50_true.extend(targets.cpu().numpy())

    return ic50_preds, ic50_true


def main():
    save_path = f'{DPATH}/eval-new2/leave_drug_fusion/{model_suffix}'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    # Load all features
    mutation_feature, drug_feature, gexpr_feature, methylation_feature, data_idx = MetadataGenerate(
        Drug_info_file,Cell_line_info_file,Genomic_mutation_file,Gene_expression_file,Methylation_file,Drug_embedding_file, Cancer_response_exp_file)

    if args.ckpt_name is not None:
        gexpr_np = np.load(f'{DPATH}/{args.ckpt_name}.npy')
        gexpr_feature = pd.DataFrame(gexpr_np, index=gexpr_feature.index)

    drugnames = list(set([item[1] for item in data_idx]))
    drugnames.sort()
    for drugname in drugnames[args.start:]:
        if os.path.exists(f"{save_path}/{drugname}.npz"):
            continue
        # Split data
        data_train_idx, data_test_idx= DrugSplit(data_idx, drugname)
        data_train_idx, data_val_idx= DataSplit(data_train_idx, TCGA_label_set, args.run_id) 

        print(f"Processing drug: {drugname}")
        print(f"Train samples: {len(data_train_idx)}, Val samples: {len(data_val_idx)}, Test samples: {len(data_test_idx)}")   

        # Extract features for each split
        X_drug_data_train, X_mutation_data_train, X_gexpr_data_train, X_methylation_data_train, Y_train, _ = FeatureExtract(
            data_train_idx, drug_feature, mutation_feature, gexpr_feature, methylation_feature)
        X_drug_data_val, X_mutation_data_val, X_gexpr_data_val, X_methylation_data_val, Y_val, _ = FeatureExtract(
            data_val_idx, drug_feature, mutation_feature, gexpr_feature, methylation_feature)
        X_drug_data_test, X_mutation_data_test, X_gexpr_data_test, X_methylation_data_test, Y_test, cancer_type_test_list = FeatureExtract(
            data_test_idx, drug_feature, mutation_feature, gexpr_feature, methylation_feature)

        # Create datasets
        data_train = HybridDataset(X_drug_data_train, X_mutation_data_train, X_gexpr_data_train, X_methylation_data_train, Y_train)
        data_val = HybridDataset(X_drug_data_val, X_mutation_data_val, X_gexpr_data_val, X_methylation_data_val, Y_val)
        data_test = HybridDataset(X_drug_data_test, X_mutation_data_test, X_gexpr_data_test, X_methylation_data_test, Y_test)

        # Data loaders
        batch_size = 64
        train_loader = DataLoader(data_train, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(data_val, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(data_test, batch_size=batch_size, shuffle=False)

        # Grid search
        results = []
        hyperparameter = {
                        'hidden_layer': args.hidden_layer,
                        'lr': args.lr,
                        'embed_dim': args.embed_dim,
                        'num_heads': args.num_heads,
                        'attn': args.attn
                    }
        num_epochs = 100
        num_train_steps = int((len(data_train) // batch_size) * num_epochs)

        # print(X_drug_data_train.shape[-1],X_mutation_data_train.shape[-1],X_gexpr_data_train.shape[-1],X_methylation_data_train.shape[-1])
        model = CDR_Attn_Model(X_gexpr_data_train.shape[-1],X_mutation_data_train.shape[-1],X_methylation_data_train.shape[-1],X_drug_data_train.shape[-1], hyperparameter, multi_omics=args.multi_omics)
        # model = CDR_Attn_Model(X_drug_data_train.shape[-1],X_mutation_data_train.shape[-1],X_gexpr_data_train.shape[-1],X_methylation_data_train.shape[-1], hyperparameter, multi_omics=False)
        optimizer = torch.optim.AdamW(model.parameters(), lr=hyperparameter['lr'])
        scheduler = get_scheduler(
            "cosine",
            optimizer=optimizer,
            num_warmup_steps=int(0.05 * num_train_steps),
            num_training_steps=num_train_steps
        )
        criterion = nn.MSELoss()

        model, pcc_history = train(model, train_loader, val_loader, optimizer, criterion, scheduler, num_epochs)
        Y_pred, Y_test = test(model, test_loader)

        np.savez(f"{save_path}/{drugname}.npz",
            cancer_type=np.array(cancer_type_test_list)[:,0],
            cellline=np.array(cancer_type_test_list)[:,1],
            pubchem_id = np.array(cancer_type_test_list)[:,2], 
            pred = Y_pred,test = Y_test)
        
                # delete to free memory
        model.cpu()
        del model, optimizer, criterion
        torch.cuda.empty_cache()
        gc.collect()


if __name__ == '__main__':
    main()
